#!/usr/bin/env python3
"""
Basic usage example for the Azure Function Logs SDK.
Demonstrates core functionality and simple monitoring.
"""

import os
import sys

# Add the src directory to the path so we can import the SDK
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from src import AzureFunctionLogsSDK


def main():
    """Demonstrate basic SDK usage."""
    
    # Initialize the SDK
    print("🚀 Initializing Azure Function Logs SDK...")
    try:
        sdk = AzureFunctionLogsSDK(
            environment="optumqa",  # or "optumdev"
            log_level="INFO"
        )
        print("✅ SDK initialized successfully!")
    except Exception as e:
        print(f"❌ SDK initialization failed: {e}")
        print("Make sure you have set the required environment variables in your .env file")
        return
    
    # Target Function App for analysis
    function_app_name = "eimp-member-search-qa"  # Replace with your Function App name
    
    print(f"\n🔍 Analyzing Function App: {function_app_name}")
    print("=" * 60)
    
    # 1. Quick Health Check
    print("\n1️⃣ Performing Health Check...")
    health_result = sdk.health_check(function_app_name, hours_back=6)
    
    if "error" not in health_result:
        status = health_result["status"]
        metrics = health_result["metrics"]
        
        print(f"   Status: {status}")
        print(f"   Total Invocations: {metrics['total_invocations']:,}")
        print(f"   Error Rate: {metrics['error_rate_percent']:.2f}%")
        print(f"   Avg Duration: {metrics['avg_duration_ms']:.2f}ms")
        
        # Show recommendations
        if health_result.get("recommendations"):
            print("   Recommendations:")
            for rec in health_result["recommendations"]:
                print(f"     • {rec}")
    else:
        print(f"   ❌ Health check failed: {health_result['error']}")
    
    # 2. Get Recent Logs
    print("\n2️⃣ Retrieving Recent Logs...")
    try:
        logs = sdk.get_logs(
            application_name=function_app_name,
            hours_back=6,
            log_level="Error",  # Only error logs
            limit=10
        )
        
        if logs:
            print(f"   Found {len(logs)} error logs:")
            for i, log in enumerate(logs[:5], 1):  # Show first 5
                timestamp = log.timestamp.strftime("%H:%M:%S")
                message = log.message[:80] + "..." if len(log.message) > 80 else log.message
                print(f"     {i}. [{timestamp}] {message}")
        else:
            print("   🟢 No error logs found - Function App is healthy!")
            
    except Exception as e:
        print(f"   ❌ Failed to retrieve logs: {e}")
    
    # 3. Performance Metrics
    print("\n3️⃣ Getting Performance Metrics...")
    try:
        metrics = sdk.get_metrics(
            function_app_name=function_app_name,
            hours_back=24,
            granularity_hours=6
        )
        
        if metrics:
            print(f"   Retrieved {len(metrics)} metric data points:")
            
            # Calculate totals
            total_invocations = sum(m.total_invocations for m in metrics)
            total_successful = sum(m.successful_invocations for m in metrics)
            total_failed = sum(m.failed_invocations for m in metrics)
            avg_duration = sum(m.avg_duration_ms for m in metrics) / len(metrics)
            
            print(f"     Total Invocations: {total_invocations:,}")
            print(f"     Success Rate: {(total_successful/total_invocations*100):.1f}%" if total_invocations > 0 else "     Success Rate: N/A")
            print(f"     Average Duration: {avg_duration:.2f}ms")
            
            # Show latest metrics
            if len(metrics) > 0:
                latest = metrics[0]  # Assuming sorted by timestamp desc
                print(f"     Latest Period: {latest.total_invocations} invocations, {latest.avg_duration_ms:.2f}ms avg")
        else:
            print("   No metrics data available")
            
    except Exception as e:
        print(f"   ❌ Failed to retrieve metrics: {e}")
    
    # 4. Error Analysis
    print("\n4️⃣ Analyzing Errors...")
    try:
        error_analysis = sdk.analyze_errors(
            function_app_name=function_app_name,
            hours_back=48,
            limit=5
        )
        
        print(f"   Total Errors: {error_analysis.total_errors}")
        print(f"   Unique Error Types: {error_analysis.unique_error_types}")
        
        if error_analysis.errors:
            print("   Top Error Types:")
            for i, error in enumerate(error_analysis.errors[:3], 1):
                print(f"     {i}. {error['exception_type']}: {error['count']} occurrences")
                print(f"        Function: {error['function_name']}")
        else:
            print("   🟢 No errors found!")
            
    except Exception as e:
        print(f"   ❌ Failed to analyze errors: {e}")
    
    # 5. Quick Analysis (combines health + error monitoring)
    print("\n5️⃣ Quick Analysis Summary...")
    try:
        quick_result = sdk.quick_analysis(function_app_name)
        
        overall_status = quick_result.get("overall_status", "UNKNOWN")
        status_emoji = {
            "HEALTHY": "🟢",
            "WARNING": "🟡", 
            "CRITICAL": "🔴",
            "UNKNOWN": "❓"
        }.get(overall_status, "❓")
        
        print(f"   Overall Status: {status_emoji} {overall_status}")
        
        # Show any alerts
        error_monitoring = quick_result.get("error_monitoring", {})
        alerts = error_monitoring.get("alerts", [])
        if alerts:
            print("   🚨 Alerts:")
            for alert in alerts:
                print(f"     • {alert}")
        else:
            print("   ✅ No alerts")
            
    except Exception as e:
        print(f"   ❌ Quick analysis failed: {e}")
    
    print(f"\n✅ Analysis complete for {function_app_name}")
    print("\n💡 Next steps:")
    print("   • Run detailed analysis with trend_analysis() for long-term insights")
    print("   • Use performance_deep_dive() for bottleneck identification")
    print("   • Generate comprehensive reports with generate_report()")
    print("   • Monitor multiple apps with generate_dashboard()")


if __name__ == "__main__":
    main()