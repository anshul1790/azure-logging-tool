import os
from dotenv import load_dotenv
import logging
from typing import List, Optional, Union, Dict, Any

from azure.identity import DefaultAzureCredential
from azure.core.exceptions import ClientAuthenticationError

from src.models.config import Environment, EnvironmentConfig, Config
from src.models.entities import FunctionAppLogEntry, FunctionAppMetrics, ErrorAnalysis
from src.models.exceptions import QueryError, AuthenticationError, ConfigurationError
from src.services.function_app_service import FunctionAppService
from src.services.logs_service import LogsService
from src.services.metrics_service import MetricsService

# Load environment variables from .env file
load_dotenv()

class AzureMainSDK:
    """
    Azure SDK for Function Apps management, discovery, logs analysis, and metrics monitoring.

    Features:
    - Environment-based configuration
    - Comprehensive error handling
    - Structured logging
    - Modular service architecture using core components
    - Centralized Azure client management
    """
    
    def __init__(self, environment: Union[Environment, str], credential: Optional[DefaultAzureCredential] = None):
        """
        Initialize the SDK.
        
        Args:
            environment: Target environment (optumdev/optumqa)
            credential: Azure credential (optional, will create DefaultAzureCredential if not provided)
        """
        # Setup logging first
        self.logger = self._setup_logging()
        
        # Parse and validate environment
        if isinstance(environment, str):
            try:
                environment = Environment(environment.lower())
            except ValueError:
                valid_envs = [e.value for e in Environment]
                raise ConfigurationError(f"Invalid environment: {environment}. Valid options: {valid_envs}")

        self.environment = environment

        # Load configuration from environment variables
        try:
            self.config = Config.get_environment_config(environment.value)
            self.logger.info(f"Loaded configuration for environment: {environment.value}")
        except ValueError as e:
            self.logger.error(f"Configuration error: {e}")
            raise ConfigurationError(f"Configuration error: {e}")

        # Initialize Azure credentials (shared across all services)
        try:
            self.credential = credential or DefaultAzureCredential()
        except Exception as e:
            raise AuthenticationError(f"Failed to initialize Azure credentials: {e}")

        # Initialize services with shared config and credentials
        # All services now use the centralized core components
        try:
            self.function_app_service = FunctionAppService(
                config=self.config,
                credential=self.credential,
                logger=self.logger
            )

            self.logs_service = LogsService(
                config=self.config,
                credential=self.credential,
                logger=self.logger
            )

            self.metrics_service = MetricsService(
                config=self.config,
                credential=self.credential,
                logger=self.logger
            )
        except Exception as e:
            raise ConfigurationError(f"Failed to initialize services: {e}")

        self.logger.info(f"Initialized AzureMainSDK for environment: {environment.value}")

    def _setup_logging(self) -> logging.Logger:
        """Setup structured logging."""
        logger = logging.getLogger(__name__)
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)

            # Get log level from environment or use INFO
            log_level = os.getenv('LOG_LEVEL', 'INFO').upper()
            logger.setLevel(getattr(logging, log_level, logging.INFO))
        return logger
    
    # Function App methods (delegate to service)
    def list_function_apps(self) -> List[str]:
        """List all Function Apps in the configured resource group."""
        return self.function_app_service.list_function_apps()

    def list_functions(self, function_app_name: str) -> List[str]:
        """List all functions in a specific Function App."""
        return self.function_app_service.list_functions(function_app_name)

    def get_function_app_info(self, function_app_name: str) -> dict:
        """Get detailed information about a Function App."""
        return self.function_app_service.get_function_app_info(function_app_name)

    def validate_function_app_exists(self, function_app_name: str) -> bool:
        """Check if a Function App exists in the resource group."""
        return self.function_app_service.validate_function_app_exists(function_app_name)

    # Logs methods (delegate to logs service)
    def get_logs(
        self,
        function_app_name: str,
        hours_back: int = 1,
        log_level: Optional[str] = "Information",
        function_name: Optional[str] = None,
        limit: int = 100
    ) -> List[FunctionAppLogEntry]:
        """Retrieve logs for a Function App."""
        return self.logs_service.get_logs(
            application_name=function_app_name,
            hours_back=hours_back,
            log_level=log_level,
            function_name=function_name,
            limit=limit
        )

    def get_error_logs(
        self,
        function_app_name: str,
        hours_back: int = 24,
        limit: int = 50
    ) -> List[FunctionAppLogEntry]:
        """Get only error-level logs for a Function App."""
        return self.logs_service.get_error_logs(
            application_name=function_app_name,
            hours_back=hours_back,
            limit=limit
        )

    def search_logs(
        self,
        function_app_name: str,
        search_term: str,
        hours_back: int = 24,
        limit: int = 100
    ) -> List[FunctionAppLogEntry]:
        """Search logs containing specific text."""
        return self.logs_service.search_logs(
            application_name=function_app_name,
            search_term=search_term,
            hours_back=hours_back,
            limit=limit
        )

    def get_function_logs(
        self,
        function_app_name: str,
        function_name: str,
        hours_back: int = 24,
        limit: int = 100
    ) -> List[FunctionAppLogEntry]:
        """Get logs for a specific function within a Function App."""
        return self.logs_service.get_function_logs(
            application_name=function_app_name,
            function_name=function_name,
            hours_back=hours_back,
            limit=limit
        )

    # Enhanced Metrics methods (now using core components)
    def get_metrics(
        self,
        function_app_name: str,
        hours_back: int = 24,
        granularity_hours: int = 1
    ) -> List[FunctionAppMetrics]:
        """Retrieve performance metrics for a Function App."""
        return self.metrics_service.get_metrics(
            function_app_name=function_app_name,
            hours_back=hours_back,
            granularity_hours=granularity_hours
        )

    def analyze_errors(
        self,
        function_app_name: str,
        hours_back: int = 24,
        limit: int = 20
    ) -> ErrorAnalysis:
        """Analyze errors and exceptions for a Function App."""
        return self.metrics_service.analyze_errors(
            function_app_name=function_app_name,
            hours_back=hours_back,
            limit=limit
        )

    def get_function_performance(
        self,
        function_app_name: str,
        hours_back: int = 24,
        function_name: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Get performance metrics grouped by individual functions."""
        return self.metrics_service.get_function_performance(
            function_app_name=function_app_name,
            hours_back=hours_back,
            function_name=function_name
        )

    def get_timeline_analysis(
        self,
        function_app_name: str,
        hours_back: int = 24,
        granularity_minutes: int = 15
    ) -> List[Dict[str, Any]]:
        """Get timeline analysis showing activity over time."""
        return self.metrics_service.get_timeline_analysis(
            function_app_name=function_app_name,
            hours_back=hours_back,
            granularity_minutes=granularity_minutes
        )

# Enhanced demo functions that show the new capabilities
def show_function_app_info(sdk: AzureMainSDK, function_app_name: str):
    """Display comprehensive Function App information."""
    print(f"=== Analyzing Function App: {function_app_name} ===\n")

    try:
        app_info = sdk.get_function_app_info(function_app_name)
        print(f"📱 App Info: {app_info['name']} in {app_info['location']} ({app_info['state']})")
        print(f"   Runtime: {app_info.get('runtime_version', 'Unknown')}")
        print(f"   Host: {app_info.get('host_name', 'Unknown')}\n")
    except Exception as e:
        print(f"❌ Could not retrieve app info: {e}\n")

def show_enhanced_metrics_demo(sdk: AzureMainSDK, function_app_name: str):
    """Demonstrate enhanced metrics functionality using core components."""
    print(f"\n=== Enhanced Metrics Demo for {function_app_name} ===\n")

    # Get metrics
    print("📊 Performance metrics (last 24 hours):")
    try:
        metrics = sdk.get_metrics(function_app_name, hours_back=24, granularity_hours=1)
        if metrics:
            latest_metric = metrics[0]
            print(f"   📈 Latest metrics:")
            print(f"   Total Invocations: {latest_metric.total_invocations}")
            print(f"   Successful: {latest_metric.successful_invocations}")
            print(f"   Failed: {latest_metric.failed_invocations}")
            print(f"   Avg Duration: {latest_metric.avg_duration_ms:.2f}ms")
            print(f"   Unique Functions: {latest_metric.unique_functions}\n")
        else:
            print("   No metrics found")
    except Exception as e:
        print(f"   Error retrieving metrics: {e}\n")

    # Enhanced error analysis
    print("🚨 Enhanced error analysis:")
    try:
        error_analysis = sdk.analyze_errors(function_app_name, hours_back=24, limit=5)
        print(f"   📊 Analysis for {error_analysis.function_app_name}")
        print(f"   🕒 Time range: {error_analysis.time_range_hours} hours")
        print(f"   🔢 Total errors: {error_analysis.total_errors}")
        print(f"   🆔 Unique error types: {error_analysis.unique_error_types}")

        if error_analysis.errors:
            print("   🔴 Top errors:")
            for i, error in enumerate(error_analysis.errors[:3], 1):
                print(f"   {i}. Function: {error['function_name']}")
                print(f"      Type: {error['exception_type']}")
                print(f"      Count: {error['count']}")
        print()
    except Exception as e:
        print(f"   Error analyzing errors: {e}\n")

    # Enhanced function performance
    print("⚡ Enhanced function performance:")
    try:
        performance = sdk.get_function_performance(function_app_name, hours_back=24)
        if performance:
            for i, func_perf in enumerate(performance[:3], 1):
                print(f"   {i}. {func_perf['function_name']}")
                print(f"      Invocations: {func_perf['invocation_count']}")
                print(f"      Success Rate: {func_perf['success_rate']:.1f}%")
                print(f"      Avg Duration: {func_perf['avg_duration_ms']:.2f}ms")
                print(f"      P95 Duration: {func_perf['p95_duration_ms']:.2f}ms")
        else:
            print("   No performance data found")
        print()
    except Exception as e:
        print(f"   Error retrieving function performance: {e}\n")

    # NEW: Timeline analysis
    print("📈 Timeline analysis (last 6 hours):")

# Example usage and testing
if __name__ == "__main__":
    try:
        # Initialize SDK for QA environment
        sdk = AzureMainSDK(Environment.OPTUMQA)

        # Specific Function App to analyze
        target_application_name = "fnc-aep-martech-directmail-optumqa"

        # Show comprehensive Function App info with logs
        show_function_app_info(sdk, target_application_name)

        # Demonstrate logs functionality
        # show_logs_demo(sdk, target_application_name)

        # Demonstrate metrics functionality
        # show_metrics_demo(sdk, target_application_name)

    except Exception as e:
        print(f"❌ Error: {e}")
