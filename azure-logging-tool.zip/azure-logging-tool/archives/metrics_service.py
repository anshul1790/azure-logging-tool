import os
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta

from azure.identity import DefaultAzureCredential
from azure.monitor.query import LogsQueryClient, LogsQueryStatus
from azure.core.exceptions import HttpResponseError, ClientAuthenticationError

from src.models.config import EnvironmentConfig
from src.models.entities import FunctionAppMetrics, ErrorAnalysis
from src.models.exceptions import QueryError, AuthenticationError

class MetricsService:
    """Service for retrieving and processing Azure Function App metrics."""
    
    def __init__(self, config: EnvironmentConfig, credential: DefaultAzureCredential, logger: Optional[logging.Logger] = None):
        """
        Initialize MetricsService with shared config and credentials.

        Args:
            config: Environment configuration
            credential: Azure credential instance
            logger: Optional logger instance
        """
        self.config = config
        self.credential = credential
        self.logger = logger or self._setup_logging()
        self._logs_client = None
        self.logger.info(f"Initialized MetricsService for Application Insights: {config.app_insights_name}")

    def _setup_logging(self) -> logging.Logger:
        logger = logging.getLogger(__name__)
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            log_level = os.getenv('LOG_LEVEL', 'INFO').upper()
            logger.setLevel(getattr(logging, log_level, logging.INFO))
        return logger

    @property
    def logs_client(self) -> LogsQueryClient:
        """Lazy initialization of Logs Query Client."""
        if self._logs_client is None:
            try:
                self._logs_client = LogsQueryClient(credential=self.credential)
                self.logger.info("Initialized LogsQueryClient")
            except ClientAuthenticationError as e:
                self.logger.error(f"Authentication failed: {e}")
                raise AuthenticationError(f"Failed to authenticate with Azure: {e}")
        return self._logs_client

    def get_metrics(
        self,
        function_app_name: str,
        hours_back: int = 24,
        granularity_hours: int = 1
    ) -> List[FunctionAppMetrics]:
        """
        Retrieve performance metrics for a Function App.
        
        Args:
            function_app_name: Name of the Function App
            hours_back: Number of hours to look back
            granularity_hours: Time granularity in hours for metrics aggregation
            
        Returns:
            List of FunctionAppMetrics objects
        """
        try:
            self.logger.info(f"Retrieving metrics for {function_app_name} (last {hours_back} hours)")
            
            query = self._build_metrics_query(
                function_app_name=function_app_name,
                hours_back=hours_back,
                granularity_hours=granularity_hours
            )
            
            self.logger.debug(f"Executing metrics query: {query}")

            timespan = timedelta(hours=hours_back)
            app_insights_resource_id = f"/subscriptions/{self.config.subscription_id}/resourceGroups/{self.config.resource_group}/providers/Microsoft.Insights/components/{self.config.app_insights_name}"

            response = self.logs_client.query_resource(
                resource_id=app_insights_resource_id,
                query=query,
                timespan=timespan
            )
            
            if response.status == LogsQueryStatus.SUCCESS and response.tables:
                metrics = self._parse_metrics_response(response.tables[0].rows)
                self.logger.info(f"Retrieved {len(metrics)} metric entries")
                return metrics
            else:
                self.logger.warning("No metrics found or query failed")
                return []
                
        except HttpResponseError as e:
            self.logger.error(f"Failed to query metrics: {e}")
            raise QueryError(f"Failed to retrieve metrics: {e}")
        except Exception as e:
            self.logger.error(f"Unexpected error retrieving metrics: {e}")
            raise QueryError(f"Unexpected error retrieving metrics: {e}")

    def analyze_errors(
        self,
        function_app_name: str,
        hours_back: int = 24,
        limit: int = 20
    ) -> ErrorAnalysis:
        """
        Analyze errors and exceptions for a Function App.
        
        Args:
            function_app_name: Name of the Function App
            hours_back: Number of hours to look back
            limit: Maximum number of error types to analyze
            
        Returns:
            ErrorAnalysis object containing error analysis results
        """
        try:
            self.logger.info(f"Analyzing errors for {function_app_name} (last {hours_back} hours)")
            
            query = self._build_error_analysis_query(
                function_app_name=function_app_name,
                hours_back=hours_back,
                limit=limit
            )

            timespan = timedelta(hours=hours_back)
            app_insights_resource_id = f"/subscriptions/{self.config.subscription_id}/resourceGroups/{self.config.resource_group}/providers/Microsoft.Insights/components/{self.config.app_insights_name}"

            response = self.logs_client.query_resource(
                resource_id=app_insights_resource_id,
                query=query,
                timespan=timespan
            )
            
            if response.status == LogsQueryStatus.SUCCESS and response.tables:
                analysis_dict = self._parse_error_analysis_response(response.tables[0].rows)

                # Return structured ErrorAnalysis object
                return ErrorAnalysis(
                    errors=analysis_dict["errors"],
                    total_errors=analysis_dict["total_errors"],
                    unique_error_types=analysis_dict["unique_error_types"],
                    time_range_hours=hours_back,
                    function_app_name=function_app_name
                )
            else:
                self.logger.warning("No error data found")
                return ErrorAnalysis(
                    errors=[],
                    total_errors=0,
                    unique_error_types=0,
                    time_range_hours=hours_back,
                    function_app_name=function_app_name
                )

        except HttpResponseError as e:
            self.logger.error(f"Failed to analyze errors: {e}")
            raise QueryError(f"Failed to analyze errors: {e}")
        except Exception as e:
            self.logger.error(f"Unexpected error analyzing errors: {e}")
            raise QueryError(f"Unexpected error analyzing errors: {e}")

    def get_function_performance(
        self,
        function_app_name: str,
        hours_back: int = 24
    ) -> List[Dict[str, Any]]:
        """
        Get performance metrics grouped by individual functions.

        Args:
            function_app_name: Name of the Function App
            hours_back: Number of hours to look back

        Returns:
            List of dictionaries containing per-function performance data
        """
        try:
            self.logger.info(f"Retrieving function performance for {function_app_name}")

            query = f"""
            requests
            | where timestamp > ago({hours_back}h)
            | where cloud_RoleName contains '{function_app_name}'
            | summarize 
                TotalCalls = count(),
                SuccessfulCalls = countif(success == true),
                FailedCalls = countif(success == false),
                AvgDuration = avg(duration),
                MaxDuration = max(duration),
                MinDuration = min(duration)
            by operation_Name
            | order by TotalCalls desc
            """

            timespan = timedelta(hours=hours_back)
            app_insights_resource_id = f"/subscriptions/{self.config.subscription_id}/resourceGroups/{self.config.resource_group}/providers/Microsoft.Insights/components/{self.config.app_insights_name}"

            response = self.logs_client.query_resource(
                resource_id=app_insights_resource_id,
                query=query,
                timespan=timespan
            )
            
            if response.status == LogsQueryStatus.SUCCESS and response.tables:
                performance_data = []
                for row in response.tables[0].rows:
                    try:
                        performance_data.append({
                            "function_name": row[0] or "Unknown",
                            "total_calls": int(row[1] or 0),
                            "successful_calls": int(row[2] or 0),
                            "failed_calls": int(row[3] or 0),
                            "avg_duration_ms": float(row[4] or 0),
                            "max_duration_ms": float(row[5] or 0),
                            "min_duration_ms": float(row[6] or 0),
                            "success_rate": (int(row[2] or 0) / int(row[1] or 1)) * 100
                        })
                    except (IndexError, TypeError, ValueError) as e:
                        self.logger.warning(f"Failed to parse performance row: {e}")
                        continue

                self.logger.info(f"Retrieved performance data for {len(performance_data)} functions")
                return performance_data
            else:
                return []
                
        except Exception as e:
            self.logger.error(f"Failed to get function performance: {e}")
            raise QueryError(f"Failed to get function performance: {e}")

    def _build_metrics_query(
        self,
        function_app_name: str,
        hours_back: int,
        granularity_hours: int
    ) -> str:
        """Build KQL query for metrics retrieval from Application Insights."""
        return f"""
        requests
        | where timestamp > ago({hours_back}h)
        | where cloud_RoleName contains '{function_app_name}'
        | summarize 
            TotalRequests = count(),
            SuccessfulRequests = countif(success == true),
            FailedRequests = countif(success == false),
            AvgDuration = avg(duration),
            UniqueOperations = dcount(operation_Name)
        by bin(timestamp, {granularity_hours}h)
        | order by timestamp desc
        """

    def _build_error_analysis_query(
        self,
        function_app_name: str,
        hours_back: int,
        limit: int
    ) -> str:
        """Build KQL query for error analysis from Application Insights."""
        return f"""
        union traces, exceptions
        | where timestamp > ago({hours_back}h)
        | where cloud_RoleName contains '{function_app_name}'
        | where severityLevel >= 3 or itemType == "exception"
        | summarize ErrorCount = count() by 
            operation_Name, 
            type = iff(itemType == "exception", type, "trace"),
            message = iff(itemType == "exception", outerMessage, message)
        | order by ErrorCount desc
        | limit {limit}
        """

    def _parse_metrics_response(self, rows: List[List[Any]]) -> List[FunctionAppMetrics]:
        """Parse Application Insights requests metrics response."""
        metrics = []
        for row in rows:
            try:
                metric = FunctionAppMetrics(
                    timestamp=row[0] if row[0] else datetime.now(),
                    total_invocations=int(row[1] or 0),
                    successful_invocations=int(row[2] or 0),
                    failed_invocations=int(row[3] or 0),
                    avg_duration_ms=float(row[4] or 0),
                    unique_functions=int(row[5] or 0)
                )
                metrics.append(metric)
            except (IndexError, TypeError, ValueError) as e:
                self.logger.warning(f"Failed to parse metrics row: {e}")
                continue

        return metrics

    def _parse_error_analysis_response(self, rows: List[List[Any]]) -> Dict[str, Any]:
        """Parse error analysis query response."""
        errors = []
        total_errors = 0

        for row in rows:
            try:
                error_info = {
                    "function_name": row[0] or "Unknown",
                    "exception_type": row[1] or "Unknown",
                    "exception_message": row[2] or "Unknown",
                    "count": int(row[3] or 0)
                }
                errors.append(error_info)
                total_errors += error_info["count"]
            except (IndexError, TypeError, ValueError) as e:
                self.logger.warning(f"Failed to parse error row: {e}")
                continue

        return {
            "errors": errors,
            "total_errors": total_errors,
            "unique_error_types": len(errors)
        }
