import os
from dotenv import load_dotenv
import json
import logging
from typing import List, Dict, Any, Optional, Union
from datetime import datetime, timedelta
from dataclasses import dataclass
from enum import Enum

from azure.identity import DefaultAzureCredential
from azure.mgmt.web import WebSiteManagementClient
from azure.monitor.query import LogsQueryClient, LogsQueryStatus
from azure.core.exceptions import (
    HttpResponseError, 
    ClientAuthenticationError, 
    ResourceNotFoundError
)

from src.services.function_app_service import FunctionAppService


# Load environment variables from .env file
load_dotenv()


class Environment(Enum):
    """Supported environments."""
    OPTUMDEV = "optumdev"
    OPTUMQA = "optumqa"


@dataclass
class EnvironmentConfig:
    """Configuration for each environment."""
    subscription_id: str
    resource_group: str
    app_insights_name: str

class Config:
    """Configuration manager."""
    
    @staticmethod
    def get_environment_config(environment: str) -> EnvironmentConfig:
        """Get configuration for specified environment from environment variables."""
        env_upper = environment.upper()
        
        subscription_id = os.getenv(f'{env_upper}_SUBSCRIPTION_ID')
        resource_group = os.getenv(f'{env_upper}_RESOURCE_GROUP')
        app_insights_name = os.getenv(f'{env_upper}_APP_INSIGHTS_NAME')
        
        if not all([subscription_id, resource_group, app_insights_name]):
            missing = [k for k, v in {
                'subscription_id': subscription_id,
                'resource_group': resource_group, 
                'app_insights_name': app_insights_name
            }.items() if not v]
            raise ValueError(f"Missing required environment variables for {environment}: {missing}")
        
        return EnvironmentConfig(
            subscription_id=subscription_id,
            resource_group=resource_group,
            app_insights_name=app_insights_name
        )


@dataclass
class ApplicationInsightsLogEntry:
    """Represents a single Function App log entry."""
    timestamp: datetime
    level: str
    message: str
    function_name: Optional[str] = None
    invocation_id: Optional[str] = None
    exception_type: Optional[str] = None
    exception_message: Optional[str] = None
    custom_properties: Optional[Dict[str, Any]] = None


@dataclass
class FunctionAppMetrics:
    """Represents Function App metrics."""
    timestamp: datetime
    total_invocations: int
    successful_invocations: int
    failed_invocations: int
    avg_duration_ms: float
    unique_functions: int


class AzureApplicationInsightsSDK:
    """    
    Features:
    - Environment-based configuration
    - Comprehensive error handling
    - Structured logging
    - Type hints and dataclasses
    - Retry logic for transient failures
    - Memory-efficient log streaming
    """
    
    def __init__(self, environment: Union[Environment, str], credential: Optional[DefaultAzureCredential] = None):
        """
        Initialize the SDK.
        
        Args:
            environment: Target environment (optumdev/optumqa)
            credential: Azure credential (optional, will create DefaultAzureCredential if not provided)
        """
        # Setup logging
        self.logger = self._setup_logging()
        
        # Parse environment
        if isinstance(environment, str):
            try:
                environment = Environment(environment.lower())
            except ValueError:
                raise ValueError(f"Invalid environment: {environment}. Valid options: {[e.value for e in Environment]}")
        
        self.environment = environment
        # Load configuration from environment variables
        try:
            self.config = Config.get_environment_config(environment.value)
            self.logger.info(f"Loaded configuration for environment: {environment.value}")
        except ValueError as e:
            self.logger.error(f"Configuration error: {e}")
            raise
        
        # Initialize Azure clients
        self.credential = credential or DefaultAzureCredential()
        self._web_client = None
        self._logs_client = None
        
        self.logger.info(f"Initialized AzureFunctionLogsSDK for environment: {environment.value}")
    
    def _setup_logging(self) -> logging.Logger:
        """Setup structured logging."""
        logger = logging.getLogger(__name__)
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)

            # Get log level from environment or use INFO
            log_level = os.getenv('LOG_LEVEL', 'INFO').upper()
            logger.setLevel(getattr(logging, log_level, logging.INFO))

            logger.setLevel(logging.INFO)
        return logger
    
    @property
    def web_client(self) -> WebSiteManagementClient:
        """Lazy initialization of Web Management Client."""
        if self._web_client is None:
            try:
                self._web_client = WebSiteManagementClient(
                    credential=self.credential,
                    subscription_id=self.config.subscription_id
                )
                self.logger.info("Initialized WebSiteManagementClient")
            except ClientAuthenticationError as e:
                self.logger.error(f"Authentication failed: {e}")
                raise
        return self._web_client
    
    @property
    def logs_client(self) -> LogsQueryClient:
        """Lazy initialization of Logs Query Client."""
        if self._logs_client is None:
            try:
                self._logs_client = LogsQueryClient(credential=self.credential)
                self.logger.info("Initialized LogsQueryClient")
            except ClientAuthenticationError as e:
                self.logger.error(f"Authentication failed: {e}")
                raise
        return self._logs_client
    
    def list_function_apps(self) -> List[str]:
        """
        List all Function Apps in the configured resource group.
        
        Returns:
            List of Function App names
        """
        try:
            self.logger.info(f"Listing Function Apps in resource group: {self.config.resource_group}")
            
            function_apps = []
            apps = self.web_client.web_apps.list_by_resource_group(self.config.resource_group)
            
            for app in apps:
                if app.kind and 'functionapp' in app.kind.lower():
                    function_apps.append(app.name)
                    self.logger.info(f"Found Function App: {app.name}")
            
            self.logger.info(f"Found {len(function_apps)} Function Apps")
            return function_apps
            
        except ResourceNotFoundError:
            self.logger.error(f"Resource group not found: {self.config.resource_group}")
            raise
        except HttpResponseError as e:
            self.logger.error(f"Failed to list Function Apps: {e}")
            raise
        except Exception as e:
            self.logger.error(f"Unexpected error listing Function Apps: {e}")
            raise
    
    def list_functions(self, function_app_name: str) -> List[str]:
        """
        List all functions in a specific Function App.
        
        Args:
            function_app_name: Name of the Function App
            
        Returns:
            List of function names
        """
        try:
            self.logger.info(f"Listing functions in Function App: {function_app_name}")
            
            functions = []
            function_list = self.web_client.web_apps.list_functions(
                resource_group_name=self.config.resource_group,
                name=function_app_name
            )
            
            for func in function_list:
                functions.append(func.name)
                self.logger.info(f"Found function: {func.name}")
            
            self.logger.info(f"Found {len(functions)} functions in {function_app_name}")
            return functions
            
        except ResourceNotFoundError:
            self.logger.error(f"Function App not found: {function_app_name}")
            raise
        except HttpResponseError as e:
            self.logger.error(f"Failed to list functions: {e}")
            raise
        except Exception as e:
            self.logger.error(f"Unexpected error listing functions: {e}")
            raise
    
    # Update your query methods to use Application Insights resource ID
    def get_logs(
        self,
        function_app_name: str,
        hours_back: int = 1,
        log_level: Optional[str] = "Information",
        function_name: Optional[str] = None,
        limit: int = 100
    ) -> List[ApplicationInsightsLogEntry]:
        """
        Retrieve logs for a Function App.
        """
        try:
            self.logger.info(f"Retrieving logs for {function_app_name} (last {hours_back} hours)")
            
            # Build KQL query
            query = self._build_logs_query(
                function_app_name=function_app_name,
                hours_back=hours_back,
                log_level=log_level,
                function_name=function_name,
                limit=limit
            )
            
            self.logger.info(f"Executing KQL query: \n{query}")

            # Calculate timespan for the query
            timespan = timedelta(hours=hours_back)
            
            # Build Application Insights resource ID
            app_insights_resource_id = f"/subscriptions/{self.config.subscription_id}/resourceGroups/{self.config.resource_group}/providers/Microsoft.Insights/components/{self.config.app_insights_name}"
            
            # Execute query using Application Insights resource
            response = self.logs_client.query_resource(
                resource_id=app_insights_resource_id,
                query=query,
                timespan=timespan
            )
            
            if response.status == LogsQueryStatus.SUCCESS and response.tables:
                logs = self._parse_log_response(response.tables[0].rows)
                self.logger.info(f"Retrieved {len(logs)} log entries")
                return logs
            else:
                self.logger.warning("No logs found or query failed")
                return []
                
        except HttpResponseError as e:
            self.logger.error(f"Failed to query logs: {e}")
            raise
        except Exception as e:
            self.logger.error(f"Unexpected error retrieving logs: {e}")
            raise


    def get_metrics(
        self,
        function_app_name: str,
        hours_back: int = 24,
        granularity_hours: int = 1
    ) -> List[FunctionAppMetrics]:
        """
        Retrieve performance metrics for a Function App.
        """
        try:
            self.logger.info(f"Retrieving metrics for {function_app_name} (last {hours_back} hours)")
            
            query = self._build_metrics_query(
                function_app_name=function_app_name,
                hours_back=hours_back,
                granularity_hours=granularity_hours
            )
            
            self.logger.info(f"Executing metrics query: {query}")

            # Add timespan parameter
            timespan = timedelta(hours=hours_back)
            
            # Build Application Insights resource ID
            app_insights_resource_id = f"/subscriptions/{self.config.subscription_id}/resourceGroups/{self.config.resource_group}/providers/Microsoft.Insights/components/{self.config.app_insights_name}"
            
            response = self.logs_client.query_resource(
                resource_id=app_insights_resource_id,
                query=query,
                timespan=timespan
            )
            
            if response.status == LogsQueryStatus.SUCCESS and response.tables:
                metrics = self._parse_metrics_response(response.tables[0].rows)
                self.logger.info(f"Retrieved {len(metrics)} metric entries")
                return metrics
            else:
                self.logger.warning("No metrics found or query failed")
                return []
                
        except HttpResponseError as e:
            self.logger.error(f"Failed to query metrics: {e}")
            raise
        except Exception as e:
            self.logger.error(f"Unexpected error retrieving metrics: {e}")
            raise

    
    def analyze_errors(
        self,
        function_app_name: str,
        hours_back: int = 24,
        limit: int = 20
    ) -> Dict[str, Any]:
        """
        Analyze errors and exceptions for a Function App.
        """
        try:
            self.logger.info(f"Analyzing errors for {function_app_name} (last {hours_back} hours)")
            
            query = self._build_error_analysis_query(
                function_app_name=function_app_name,
                hours_back=hours_back,
                limit=limit
            )

            # Add timespan parameter
            timespan = timedelta(hours=hours_back)
            
            # Build Application Insights resource ID
            app_insights_resource_id = f"/subscriptions/{self.config.subscription_id}/resourceGroups/{self.config.resource_group}/providers/Microsoft.Insights/components/{self.config.app_insights_name}"
            
            response = self.logs_client.query_resource(
                resource_id=app_insights_resource_id,
                query=query,
                timespan=timespan
            )
            
            if response.status == LogsQueryStatus.SUCCESS and response.tables:
                analysis = self._parse_error_analysis_response(response.tables[0].rows)
                self.logger.info(f"Analyzed {len(analysis.get('errors', []))} error types")
                return analysis
            else:
                self.logger.warning("No error data found")
                return {"errors": [], "total_errors": 0}
                
        except HttpResponseError as e:
            self.logger.error(f"Failed to analyze errors: {e}")
            raise
        except Exception as e:
            self.logger.error(f"Unexpected error analyzing errors: {e}")
            raise
    
    def _build_logs_query(
        self,
        function_app_name: str,
        hours_back: int,
        log_level: Optional[str],
        function_name: Optional[str],
        limit: int
    ) -> str:
        """Build KQL query for logs retrieval from Application Insights."""
        query_parts = [
            "traces",
            f"| where timestamp > ago({hours_back}h)",
            f"| where cloud_RoleName contains '{function_app_name}'"
        ]
    
        # Filter by severity level if specified
        if log_level:
            severity_map = {
                "Error": "3",
                "Warning": "2", 
                "Information": "1",
                "Verbose": "0"
            }
            severity = severity_map.get(log_level, log_level)
            query_parts.append(f"| where severityLevel == {severity}")
        
        # Filter by function name if specified
        if function_name:
            query_parts.append(f"| where operation_Name contains '{function_name}' or message contains '{function_name}'")
        
        # Exclude common noise
        query_parts.append('| where message != "WorkerStatusRequest completed"')
        
        query_parts.extend([
            f"| limit {limit}",
            "| project timestamp, severityLevel, message, operation_Name, operation_Id, customDimensions"
        ])
        
        return "\n".join(query_parts)
    
    def _build_metrics_query(
        self,
        function_app_name: str,
        hours_back: int,
        granularity_hours: int
    ) -> str:
        """Build KQL query for metrics retrieval from Application Insights."""
        return f"""
        requests
        | where timestamp > ago({hours_back}h)
        | where cloud_RoleName contains '{function_app_name}'
        | summarize 
            TotalRequests = count(),
            SuccessfulRequests = countif(success == true),
            FailedRequests = countif(success == false),
            AvgDuration = avg(duration),
            UniqueOperations = dcount(operation_Name)
        by bin(timestamp, {granularity_hours}h)
        """
    
    def _build_error_analysis_query(
        self,
        function_app_name: str,
        hours_back: int,
        limit: int
    ) -> str:
        """Build KQL query for error analysis from Application Insights."""
        return f"""
        union traces, exceptions
        | where timestamp > ago({hours_back}h)
        | where cloud_RoleName contains '{function_app_name}'
        | where severityLevel >= 3 or itemType == "exception"
        | summarize ErrorCount = count() by 
            operation_Name, 
            type = iff(itemType == "exception", type, "trace"),
            message = iff(itemType == "exception", outerMessage, message)
        | order by ErrorCount desc
        | limit {limit}
        """
    
    def _parse_log_response(self, rows: List[List[Any]]) -> List[ApplicationInsightsLogEntry]:
        """Parse Application Insights traces response into FunctionAppLogEntry objects."""
        logs = []
        
        # Severity level mapping for Application Insights
        severity_map = {
            0: "Verbose",
            1: "Information", 
            2: "Warning",
            3: "Error"
        }
        
        for row in rows:
            try:
                custom_props = None
                if len(row) > 5 and row[5]:
                    try:
                        custom_props = json.loads(row[5]) if isinstance(row[5], str) else row[5]
                    except (json.JSONDecodeError, TypeError):
                        custom_props = {"raw": str(row[5])}
                
                log_entry = ApplicationInsightsLogEntry(
                    timestamp=row[0] if row[0] else datetime.now(),
                    level=severity_map.get(int(row[1]), "Unknown") if row[1] is not None else "Unknown",
                    message=row[2] or "",
                    function_name=row[3],  # operation_Name
                    invocation_id=row[4],  # operation_Id
                    exception_type=None,   # Not available in traces
                    exception_message=None,
                    custom_properties=custom_props
                )
                logs.append(log_entry)
            except (IndexError, TypeError, ValueError) as e:
                self.logger.warning(f"Failed to parse log row: {e}")
                continue
        
        return logs

    def _parse_metrics_response(self, rows: List[List[Any]]) -> List[FunctionAppMetrics]:
        """Parse Application Insights requests metrics response."""
        metrics = []
        for row in rows:
            try:
                metric = FunctionAppMetrics(
                    timestamp=row[0] if row[0] else datetime.now(),
                    total_invocations=int(row[1] or 0),
                    successful_invocations=int(row[2] or 0),
                    failed_invocations=int(row[3] or 0),
                    avg_duration_ms=float(row[4] or 0),
                    unique_functions=int(row[5] or 0)
                )
                metrics.append(metric)
            except (IndexError, TypeError, ValueError) as e:
                self.logger.warning(f"Failed to parse metrics row: {e}")
                continue
        
        return metrics
    
    def _parse_error_analysis_response(self, rows: List[List[Any]]) -> Dict[str, Any]:
        """Parse error analysis query response."""
        errors = []
        total_errors = 0
        
        for row in rows:
            try:
                error_info = {
                    "function_name": row[0] or "Unknown",
                    "exception_type": row[1] or "Unknown",
                    "exception_message": row[2] or "Unknown",
                    "count": int(row[3] or 0)
                }
                errors.append(error_info)
                total_errors += error_info["count"]
            except (IndexError, TypeError, ValueError) as e:
                self.logger.warning(f"Failed to parse error row: {e}")
                continue
        
        return {
            "errors": errors,
            "total_errors": total_errors,
            "unique_error_types": len(errors)
        }


# Example usage and testing
if __name__ == "__main__":
    # Example usage
    try:
        # Initialize SDK for dev environment
        sdk = AzureApplicationInsightsSDK(Environment.OPTUMQA)
        
        # Specific Function App to analyze
        # target_application_name = "oh-offers-ogm-ibrh-ingest-optumqa"
        target_application_name = "fnc-aep-martech-directmail-optumqa"

        print(f"=== Analyzing Function App: {target_application_name} ===\n")
        
        # Get logs for the specific Function App
        print("📋 Retrieving logs...")
        logs = sdk.get_logs(target_application_name, hours_back=6, limit=50)
        print(f"Retrieved {len(logs)} log entries\n")
        
        # Print recent logs
        if logs:
            print("🔍 Recent logs:")
            for i, log in enumerate(logs[:50]):  # Show first 50 logs
                print(f"{i+1}. [{log.timestamp}] {log.level}: {log.message[:100]}...")
            print()
        
        # Get metrics
        print("📊 Retrieving metrics...")
        metrics = sdk.get_metrics(target_application_name, hours_back=24)
        print(f"Retrieved {len(metrics)} metric entries\n")
        
        # Print metrics summary
        if metrics:
            latest_metric = metrics[0]
            print(f"📈 Latest metrics:")
            print(f"   Total Invocations: {latest_metric.total_invocations}")
            print(f"   Successful: {latest_metric.successful_invocations}")
            print(f"   Failed: {latest_metric.failed_invocations}")
            print(f"   Avg Duration: {latest_metric.avg_duration_ms:.2f}ms")
            print(f"   Unique Functions: {latest_metric.unique_functions}\n")
        
        # Analyze errors
        print("🚨 Analyzing errors...")
        error_analysis = sdk.analyze_errors(target_application_name, hours_back=24)
        print(f"Found {error_analysis['total_errors']} total errors across {error_analysis['unique_error_types']} error types\n")
        
        # Print error details
        if error_analysis['errors']:
            print("🔴 Top errors:")
            for i, error in enumerate(error_analysis['errors'][:3]):  # Show top 3 errors
                print(f"{i+1}. Function: {error['function_name']}")
                print(f"   Type: {error['exception_type']}")
                print(f"   Message: {error['exception_message'][:100]}...")
                print(f"   Count: {error['count']}\n")
        
        # Optional: List all functions in the app
        # print("⚙️ Functions in this app:")
        # try:
        #     functions = sdk.list_functions(target_function_app)
        #     for func in functions:
        #         print(f"   - {func}")
        # except Exception as e:
        #     print(f"   Could not retrieve functions: {e}")
    
    except Exception as e:
        print(f"❌ Error: {e}")
