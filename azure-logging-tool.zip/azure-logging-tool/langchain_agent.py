"""
LangChain Agent for Azure Logging Tool
Provides dynamic tools for querying logs and metrics with AI-powered interpretation.
"""

import os
from typing import Optional

from langchain.tools import tool
from langchain.agents import initialize_agent, AgentType
from langchain.llms import OpenAI
from langchain.memory import ConversationBufferMemory

from src.core.azure_observability_sdk import AzureObservabilitySDK
from src.models.config import Environment


class AzureLoggingAgent:
    """LangChain agent for Azure logging and metrics queries."""

    def __init__(self, environment: str = "optumqa", openai_api_key: Optional[str] = None):
        """Initialize the agent with Azure SDK and LLM."""
        self.sdk = AzureObservabilitySDK(Environment(environment.lower()))

        # Initialize LLM
        api_key = openai_api_key or os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OpenAI API key is required. Set OPENAI_API_KEY environment variable.")

        self.llm = OpenAI(temperature=0.3, openai_api_key=api_key)
        self.interpretation_llm = OpenAI(temperature=0.7, openai_api_key=api_key)

        # Initialize memory for conversation context
        self.memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)

        # Initialize agent with tools
        self.tools = self._create_tools()
        self.agent = self._initialize_agent()

    def _create_tools(self):
        """Create dynamic tools for the agent."""

        @tool
        def list_function_apps() -> str:
            """List all available Function Apps in the Azure resource group."""
            try:
                apps = self.sdk.list_function_apps()
                if apps:
                    return f"Available Function Apps:\n" + "\n".join([f"- {app}" for app in apps])
                else:
                    return "No Function Apps found in the resource group."
            except Exception as e:
                return f"Error listing Function Apps: {str(e)}"

        @tool
        def get_application_logs(application_name: str, hours_back: int = 1, limit: int = 100, log_level: str = "Information") -> str:
            """
            Fetch logs for a specific application.

            Args:
                application_name: Name of the Azure Function App
                hours_back: Number of hours to look back (default: 1)
                limit: Maximum number of logs to retrieve (default: 100)
                log_level: Log level filter - Error, Warning, Information, Verbose (default: Information)
            """
            try:
                logs = self.sdk.get_logs(
                    application_name=application_name,
                    hours_back=hours_back,
                    limit=limit,
                    log_level=log_level
                )

                if not logs:
                    return f"No logs found for {application_name} in the last {hours_back} hours."

                log_summary = f"Found {len(logs)} logs for {application_name} (last {hours_back} hours):\n\n"

                for i, log in enumerate(logs[:10], 1):  # Show first 10 logs
                    timestamp = log.timestamp.strftime("%Y-%m-%d %H:%M:%S") if log.timestamp else "Unknown"
                    message_preview = log.message[:200] + "..." if len(log.message) > 200 else log.message
                    log_summary += f"{i}. [{timestamp}] {log.level}: {message_preview}\n"

                if len(logs) > 10:
                    log_summary += f"\n... and {len(logs) - 10} more logs."

                return log_summary

            except Exception as e:
                return f"Error retrieving logs for {application_name}: {str(e)}"

        @tool
        def get_error_logs(application_name: str, hours_back: int = 24, limit: int = 50) -> str:
            """
            Fetch only error-level logs for a specific application.

            Args:
                application_name: Name of the Azure Function App
                hours_back: Number of hours to look back (default: 24)
                limit: Maximum number of error logs to retrieve (default: 50)
            """
            try:
                error_logs = self.sdk.get_error_logs(
                    function_app_name=application_name,
                    hours_back=hours_back,
                    limit=limit
                )

                if not error_logs:
                    return f"No error logs found for {application_name} in the last {hours_back} hours."

                error_summary = f"Found {len(error_logs)} error logs for {application_name} (last {hours_back} hours):\n\n"

                for i, log in enumerate(error_logs, 1):
                    timestamp = log.timestamp.strftime("%Y-%m-%d %H:%M:%S") if log.timestamp else "Unknown"
                    message_preview = log.message[:150] + "..." if len(log.message) > 150 else log.message
                    error_summary += f"{i}. [{timestamp}] ERROR: {message_preview}\n"

                return error_summary

            except Exception as e:
                return f"Error retrieving error logs for {application_name}: {str(e)}"

        @tool
        def search_logs_by_term(application_name: str, search_term: str, hours_back: int = 24, limit: int = 100) -> str:
            """
            Search for logs containing specific text or terms.

            Args:
                application_name: Name of the Azure Function App
                search_term: Text to search for in log messages
                hours_back: Number of hours to look back (default: 24)
                limit: Maximum number of logs to retrieve (default: 100)
            """
            try:
                search_results = self.sdk.search_logs(
                    function_app_name=application_name,
                    search_term=search_term,
                    hours_back=hours_back,
                    limit=limit
                )

                if not search_results:
                    return f"No logs containing '{search_term}' found for {application_name} in the last {hours_back} hours."

                search_summary = f"Found {len(search_results)} logs containing '{search_term}' for {application_name}:\n\n"

                for i, log in enumerate(search_results[:8], 1):  # Show first 8 results
                    timestamp = log.timestamp.strftime("%Y-%m-%d %H:%M:%S") if log.timestamp else "Unknown"
                    message_preview = log.message[:180] + "..." if len(log.message) > 180 else log.message
                    search_summary += f"{i}. [{timestamp}] {log.level}: {message_preview}\n"

                if len(search_results) > 8:
                    search_summary += f"\n... and {len(search_results) - 8} more results."

                return search_summary

            except Exception as e:
                return f"Error searching logs for {application_name}: {str(e)}"

        @tool
        def get_application_metrics(application_name: str, hours_back: int = 24, granularity_hours: int = 1) -> str:
            """
            Fetch performance metrics for a specific application.

            Args:
                application_name: Name of the Azure Function App
                hours_back: Number of hours to look back (default: 24)
                granularity_hours: Time granularity in hours for metrics aggregation (default: 1)
            """
            try:
                metrics = self.sdk.get_metrics(
                    function_app_name=application_name,
                    hours_back=hours_back,
                    granularity_hours=granularity_hours
                )

                if not metrics:
                    return f"No metrics found for {application_name} in the last {hours_back} hours."

                latest_metric = metrics[0]
                metrics_summary = f"Performance metrics for {application_name} (last {hours_back} hours):\n\n"
                metrics_summary += f"📊 Latest metrics:\n"
                metrics_summary += f"   • Total Invocations: {latest_metric.total_invocations}\n"
                metrics_summary += f"   • Successful: {latest_metric.successful_invocations}\n"
                metrics_summary += f"   • Failed: {latest_metric.failed_invocations}\n"
                metrics_summary += f"   • Average Duration: {latest_metric.avg_duration_ms:.2f}ms\n"
                metrics_summary += f"   • Unique Functions: {latest_metric.unique_functions}\n"

                if len(metrics) > 1:
                    metrics_summary += f"\n📈 Trend (last {min(5, len(metrics))} time periods):\n"
                    for i, metric in enumerate(metrics[:5]):
                        timestamp = metric.timestamp.strftime("%m-%d %H:%M") if metric.timestamp else "Unknown"
                        success_rate = (metric.successful_invocations / max(metric.total_invocations, 1)) * 100
                        metrics_summary += f"   [{timestamp}] Total: {metric.total_invocations}, Success Rate: {success_rate:.1f}%\n"

                return metrics_summary

            except Exception as e:
                return f"Error retrieving metrics for {application_name}: {str(e)}"

        @tool
        def analyze_application_errors(application_name: str, hours_back: int = 24, limit: int = 20) -> str:
            """
            Analyze errors and exceptions for a specific application.

            Args:
                application_name: Name of the Azure Function App
                hours_back: Number of hours to look back (default: 24)
                limit: Maximum number of error types to analyze (default: 20)
            """
            try:
                error_analysis = self.sdk.analyze_errors(
                    function_app_name=application_name,
                    hours_back=hours_back,
                    limit=limit
                )

                analysis_summary = f"Error analysis for {application_name} (last {hours_back} hours):\n\n"
                analysis_summary += f"📊 Summary:\n"
                analysis_summary += f"   • Total errors: {error_analysis.total_errors}\n"
                analysis_summary += f"   • Unique error types: {error_analysis.unique_error_types}\n"

                if error_analysis.errors and error_analysis.total_errors > 0:
                    analysis_summary += f"\n🔴 Top errors:\n"
                    for i, error in enumerate(error_analysis.errors[:5], 1):
                        analysis_summary += f"   {i}. Function: {error['function_name']}\n"
                        analysis_summary += f"      Type: {error['exception_type']}\n"
                        error_msg = error['exception_message'][:100] + "..." if len(error['exception_message']) > 100 else error['exception_message']
                        analysis_summary += f"      Message: {error_msg}\n"
                        analysis_summary += f"      Count: {error['count']}\n\n"
                else:
                    analysis_summary += "\n✅ No errors found in the specified time range."

                return analysis_summary

            except Exception as e:
                return f"Error analyzing errors for {application_name}: {str(e)}"

        @tool
        def interpret_logs_with_ai(application_name: str, log_count: int = 50, hours_back: int = 24) -> str:
            """
            Use AI to interpret and analyze logs for patterns, issues, and insights.

            Args:
                application_name: Name of the Azure Function App
                log_count: Number of recent logs to analyze (default: 50)
                hours_back: Number of hours to look back (default: 24)
            """
            try:
                # Fetch logs for analysis
                logs = self.sdk.get_logs(
                    application_name=application_name,
                    hours_back=hours_back,
                    limit=log_count
                )

                if not logs:
                    return f"No logs found for {application_name} to analyze."

                # Prepare log data for AI analysis
                log_messages = []
                error_count = 0
                warning_count = 0

                for log in logs:
                    timestamp = log.timestamp.strftime("%H:%M:%S") if log.timestamp else "Unknown"
                    log_messages.append(f"[{timestamp}] {log.level}: {log.message}")
                    if log.level == "Error":
                        error_count += 1
                    elif log.level == "Warning":
                        warning_count += 1

                # Prepare prompt for AI interpretation
                log_text = "\n".join(log_messages[:30])  # Use first 30 logs for analysis

                prompt = f"""
                You are an expert Azure Function App monitoring specialist. Analyze the following logs for the application '{application_name}':

                Log Summary:
                - Total logs analyzed: {len(logs)}
                - Error logs: {error_count}
                - Warning logs: {warning_count}
                - Time range: Last {hours_back} hours

                Recent Logs:
                {log_text}

                Please provide a comprehensive analysis including:
                1. Overall application health assessment
                2. Recurring patterns or issues identified
                3. Performance indicators
                4. Recommendations for investigation or improvement
                5. Any critical issues that need immediate attention

                Keep the analysis concise but thorough.
                """

                # Get AI interpretation
                interpretation = self.interpretation_llm(prompt)

                return f"🤖 AI Analysis for {application_name}:\n\n{interpretation}"

            except Exception as e:
                return f"Error interpreting logs for {application_name}: {str(e)}"

        @tool
        def suggest_error_fixes(application_name: str, hours_back: int = 24) -> str:
            """
            Analyze recent errors and suggest potential fixes using AI.

            Args:
                application_name: Name of the Azure Function App
                hours_back: Number of hours to look back for errors (default: 24)
            """
            try:
                # Get recent error logs
                error_logs = self.sdk.get_error_logs(
                    function_app_name=application_name,
                    hours_back=hours_back,
                    limit=20
                )

                if not error_logs:
                    return f"No error logs found for {application_name} in the last {hours_back} hours."

                # Prepare error data for AI analysis
                error_messages = []
                for error in error_logs:
                    timestamp = error.timestamp.strftime("%H:%M:%S") if error.timestamp else "Unknown"
                    error_messages.append(f"[{timestamp}] {error.function_name}: {error.message}")

                error_text = "\n".join(error_messages[:15])  # Use first 15 errors

                prompt = f"""
                You are an expert Azure Function App troubleshooting specialist. Analyze the following error logs for '{application_name}' and suggest specific fixes:

                Recent Errors (last {hours_back} hours):
                {error_text}

                For each type of error identified, please provide:
                1. Root cause analysis
                2. Specific steps to fix the issue
                3. Prevention strategies
                4. Priority level (Critical/High/Medium/Low)

                Focus on actionable solutions and best practices.
                """

                # Get AI suggestions
                suggestions = self.interpretation_llm(prompt)

                return f"🔧 Error Fix Suggestions for {application_name}:\n\n{suggestions}"

            except Exception as e:
                return f"Error generating fix suggestions for {application_name}: {str(e)}"

        return [
            list_function_apps,
            get_application_logs,
            get_error_logs,
            search_logs_by_term,
            get_application_metrics,
            analyze_application_errors,
            interpret_logs_with_ai,
            suggest_error_fixes
        ]

    def _initialize_agent(self):
        """Initialize the LangChain agent with tools and memory."""
        return initialize_agent(
            self.tools,
            self.llm,
            agent=AgentType.CONVERSATIONAL_REACT_DESCRIPTION,
            verbose=True,
            memory=self.memory,
            max_iterations=3,
            early_stopping_method="generate"
        )

    def query(self, user_input: str) -> str:
        """Process user query through the agent."""
        try:
            response = self.agent.run(input=user_input)
            return response
        except Exception as e:
            return f"Error processing query: {str(e)}"


# Example usage and testing
if __name__ == "__main__":
    # Initialize the agent
    agent = AzureLoggingAgent(environment="optumqa")

    # Example queries
    test_queries = [
        "List all available Function Apps",
        "Fetch logs for martech-directmail-optumqa service in the last 3 hours with limit 100",
        "Show me error logs for martech-directmail-optumqa from the last 24 hours",
        "Search for 'timeout' in martech-directmail-optumqa logs",
        "Get performance metrics for martech-directmail-optumqa",
        "Analyze errors in martech-directmail-optumqa and interpret what they mean",
        "Suggest fixes for recent errors in martech-directmail-optumqa"
    ]

    print("🤖 Azure Logging Agent Initialized")
    print("="*50)

    # Interactive mode
    while True:
        try:
            user_query = input("\n💬 Enter your query (or 'quit' to exit): ")
            if user_query.lower() in ['quit', 'exit', 'q']:
                break

            print(f"\n🔄 Processing: {user_query}")
            response = agent.query(user_query)
            print(f"\n📋 Response:\n{response}")

        except KeyboardInterrupt:
            print("\n👋 Goodbye!")
            break
        except Exception as e:
            print(f"\n❌ Error: {e}")
