from ..core.azure_observability_sdk import AzureObservabilitySDK
from ..models import Environment

from langchain.tools import tool


class LoggingTools:

    def __init__(self, environment: str):
        self.environment = environment

    @tool
    def get_application_logs(self, application_name: str, hours_back: int = 1, limit: int = 100, log_level: str = "Information",) -> str:
        """
        Retrieve and summarize logs for a specified function app within a given time frame.
        """
        try:
            sdk = AzureObservabilitySDK(Environment(self.environment .lower()))
            logs = sdk.get_logs(
                application_name=application_name,
                hours_back=hours_back,
                limit=limit,
                log_level=log_level
            )

            if not logs:
                return f"No logs found for {application_name} in the last {hours_back} hours."

            log_summary = f"Found {len(logs)} logs for {application_name} (last {hours_back} hours):\n\n"

            for i, log in enumerate(logs[:10], 1):  # Show first 10 logs
                timestamp = log.timestamp.strftime("%Y-%m-%d %H:%M:%S") if log.timestamp else "Unknown"
                message_preview = log.message[:200] + "..." if len(log.message) > 200 else log.message
                log_summary += f"{i}. [{timestamp}] {log.level}: {message_preview}\n"

            if len(logs) > 10:
                log_summary += f"\n... and {len(logs) - 10} more logs."

            return log_summary

        except Exception as e:
            return f"Error retrieving logs for {application_name}: {str(e)}"
