from ..core.azure_observability_sdk import AzureObservabilitySDK
from ..models import Environment

from langchain.tools import tool


class FunctionAppTool:

    def __init__(self, environment: str):
        self.environment = environment

    @tool
    def list_function_apps(self) -> str:
        """List all the available function apps in a given azure subscription."""
        sdk = AzureObservabilitySDK(Environment(self.environment.lower()))
        apps = sdk.list_function_apps()
        if not apps:
            return "No function apps found in the subscription."
        app_list = "Available Function Apps:\n"
        for i, app in enumerate(apps, 1):
            # Handle both dict/object and string cases
            if hasattr(app, 'name') and hasattr(app, 'resource_group'):
                app_list += f"{i}. {app.name} (Resource Group: {app.resource_group})\n"
            elif isinstance(app, dict) and 'name' in app and 'resource_group' in app:
                app_list += f"{i}. {app['name']} (Resource Group: {app['resource_group']})\n"
            else:
                app_list += f"{i}. {str(app)}\n"
        return app_list

    @tool
    def function_app_details(self, function_app_name: str) -> str:
        """Get the details of a given function app."""
        try:
            sdk = AzureObservabilitySDK(Environment(self.environment.lower()))
            details = sdk.get_function_app_info(function_app_name)

            if not details:
                return f"Function app '{function_app_name}' not found."

            return f"Function App Details for {function_app_name}:\n{details}"
        except Exception as e:
            return f"Error getting details for {function_app_name}: {str(e)}"
