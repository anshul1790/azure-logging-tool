"""
Demo script for Azure LangChain Agent
Shows how the agent handles dynamic queries with various parameters
"""

import os
from langchain_agent import AzureLoggingAgent

def demo_dynamic_queries():
    """Demonstrate various dynamic query capabilities."""

    # Initialize the agent
    print("🚀 Initializing Azure Logging Agent...")
    agent = AzureLoggingAgent(environment="optumqa")
    print("✅ Agent initialized successfully!\n")

    # Dynamic query examples covering all 5 concepts
    dynamic_queries = [
        # 1. Application name variations
        "List all Function Apps",
        "Show me logs for martech-directmail-optumqa",
        "Get logs for fnc-aep-martech-directmail-optumqa application",

        # 2. Time ago variations
        "Fetch logs for martech-directmail-optumqa from the last 3 hours",
        "Show me error logs from the past 6 hours for martech-directmail-optumqa",
        "Get logs for martech-directmail-optumqa from 12 hours ago",

        # 3. Time range variations
        "Show logs for martech-directmail-optumqa between last 2 to 8 hours",
        "Get metrics for martech-directmail-optumqa over the past 24 hours with 2-hour granularity",

        # 4. Limit variations
        "Fetch only 50 logs for martech-directmail-optumqa",
        "Show me the top 20 error logs for martech-directmail-optumqa",
        "Get first 100 logs from martech-directmail-optumqa in the last 4 hours",

        # 5. AI-powered non-deterministic queries
        "Analyze and interpret the health of martech-directmail-optumqa application",
        "What patterns do you see in martech-directmail-optumqa logs?",
        "Suggest fixes for errors in martech-directmail-optumqa",
        "Explain what's happening with martech-directmail-optumqa based on recent logs",

        # Complex combined queries
        "Get 75 error logs from martech-directmail-optumqa in the last 8 hours and analyze them",
        "Search for 'timeout' in martech-directmail-optumqa logs from past 12 hours, limit 30 results",
        "Show performance metrics for martech-directmail-optumqa over 48 hours and interpret the trends"
    ]

    print("🎯 Testing Dynamic Query Capabilities")
    print("="*60)

    for i, query in enumerate(dynamic_queries, 1):
        print(f"\n📝 Query {i}: {query}")
        print("-" * 50)

        try:
            response = agent.query(query)
            print(f"🤖 Agent Response:\n{response}")
        except Exception as e:
            print(f"❌ Error: {e}")

        print("\n" + "="*60)

        # Add a small pause for readability in demo
        if i % 3 == 0:
            input("Press Enter to continue...")

def interactive_mode():
    """Interactive mode for testing custom queries."""

    print("🎮 Interactive Mode - Test Your Own Queries")
    print("="*50)

    agent = AzureLoggingAgent(environment="optumqa")

    print("\n💡 Example queries you can try:")
    print("- 'Get logs for [app-name] in the last [X] hours'")
    print("- 'Show me [X] error logs for [app-name]'")
    print("- 'Analyze the health of [app-name]'")
    print("- 'Search for [term] in [app-name] logs'")
    print("- 'Get metrics for [app-name] over [X] hours'")
    print("- 'Suggest fixes for [app-name] errors'")

    while True:
        try:
            user_query = input("\n💬 Your query (or 'quit' to exit): ")

            if user_query.lower() in ['quit', 'exit', 'q', 'stop']:
                print("👋 Goodbye!")
                break

            if not user_query.strip():
                continue

            print(f"\n🔄 Processing: {user_query}")
            response = agent.query(user_query)
            print(f"\n📋 Response:\n{response}")

        except KeyboardInterrupt:
            print("\n👋 Goodbye!")
            break
        except Exception as e:
            print(f"\n❌ Error: {e}")

def show_tool_capabilities():
    """Show what each tool can handle dynamically."""

    print("🛠️  Available Dynamic Tools & Capabilities")
    print("="*60)

    tools_info = [
        {
            "name": "list_function_apps",
            "description": "Lists all available Function Apps",
            "dynamic_params": "None - always returns current apps"
        },
        {
            "name": "get_application_logs",
            "description": "Fetches logs for any application",
            "dynamic_params": "application_name, hours_back, limit, log_level"
        },
        {
            "name": "get_error_logs",
            "description": "Gets only error-level logs",
            "dynamic_params": "application_name, hours_back, limit"
        },
        {
            "name": "search_logs_by_term",
            "description": "Searches logs for specific text",
            "dynamic_params": "application_name, search_term, hours_back, limit"
        },
        {
            "name": "get_application_metrics",
            "description": "Fetches performance metrics",
            "dynamic_params": "application_name, hours_back, granularity_hours"
        },
        {
            "name": "analyze_application_errors",
            "description": "Analyzes error patterns",
            "dynamic_params": "application_name, hours_back, limit"
        },
        {
            "name": "interpret_logs_with_ai",
            "description": "AI-powered log interpretation",
            "dynamic_params": "application_name, log_count, hours_back + AI analysis"
        },
        {
            "name": "suggest_error_fixes",
            "description": "AI-powered error fix suggestions",
            "dynamic_params": "application_name, hours_back + AI recommendations"
        }
    ]

    for tool in tools_info:
        print(f"\n🔧 {tool['name']}")
        print(f"   📝 {tool['description']}")
        print(f"   ⚙️  Dynamic Parameters: {tool['dynamic_params']}")

    print(f"\n🎯 Key Dynamic Concepts Supported:")
    print(f"   1. 📱 Application Name - Any valid Function App name")
    print(f"   2. ⏰ Time Ago - Hours back (1-168 hours supported)")
    print(f"   3. 📅 Time Range - Via hours_back + granularity parameters")
    print(f"   4. 🔢 Limit - Max records to return (1-1000)")
    print(f"   5. 🤖 AI Analysis - Non-deterministic insights using LLM")

if __name__ == "__main__":
    print("🎯 Azure Logging Agent Demo")
    print("="*40)

    mode = input("""
Choose demo mode:
1. Show tool capabilities
2. Run dynamic query examples  
3. Interactive mode
Enter choice (1-3): """).strip()

    if mode == "1":
        show_tool_capabilities()
    elif mode == "2":
        demo_dynamic_queries()
    elif mode == "3":
        interactive_mode()
    else:
        print("Invalid choice. Running tool capabilities overview...")
        show_tool_capabilities()
